package com.example.user.a20181206;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class PatchActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patch);
    }
}
